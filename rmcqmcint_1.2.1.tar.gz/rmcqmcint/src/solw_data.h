#pragma once
#ifndef SOLW_DATA_H
#define SOLW_DATA_H
#include "digital_data.h"
#endif // SOLW_DATA_H
