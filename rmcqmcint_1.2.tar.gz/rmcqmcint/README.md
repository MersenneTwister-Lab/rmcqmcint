# rmcqmcint
R language, Monte-Carlo Quasi Monte-Carlo Integration

Caution: Currently, this project is very experimental.