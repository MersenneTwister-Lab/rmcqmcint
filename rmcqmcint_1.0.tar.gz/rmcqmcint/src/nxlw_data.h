#pragma once
#ifndef NXLW_DATA_H
#define NXLW_DATA_H
#include "digital_data.h"
#endif // DIGITAL_DATA_H
